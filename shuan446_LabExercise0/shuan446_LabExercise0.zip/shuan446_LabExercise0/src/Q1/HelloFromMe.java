/*******************************************
 Shih Chen Huang
 251282167
 Jan 23, 2023
 The following code prints out the creators name, student number, and creation date.
 *********************************************/
package Q1;//Indicating that this is from the package Q1.

public class HelloFromMe { //Creating a class HelloFromMe. Java needs a class to implement any code
    public static void main(String[] args) {/*main() method, entry point in Java.
                                              Also known as the driver method*/
        System.out.println("Hello! This is Shih Chen Huang.\n" +
                "Student Number: 251282167\n" +
                "Date: Jan 23, 2023\n" +
                "The rollercoaster fun-ride begins here!\n" +
                "Goodbye for now!\n");/*Prints an introduction of the student and some greetings,
                                        then concludes the program.*/
    }
}
